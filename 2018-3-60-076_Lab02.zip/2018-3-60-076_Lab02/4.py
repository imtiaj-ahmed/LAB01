def rem_vowel(string):
    vowels = ['a','e','i','o','u','A','E','I','O','U']
    result = [letter for letter in string if letter.lower() not in vowels]
    result = ''.join(result)
    print(result)
 
string = "The quick brown fox jumps over the lazy dog"
rem_vowel(string)
